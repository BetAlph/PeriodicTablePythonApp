periodicTableAppMain = {
"Hydrogen": 1, 
"Helium": 2,
"Lithium": 3
}
